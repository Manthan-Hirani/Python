a = "Python Developer"
# b = slice(0,len(a),2) 
# print(a[b])

print(a[::2])