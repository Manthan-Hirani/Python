a = "Prometheus"

print(a[4:])